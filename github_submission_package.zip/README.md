# Revenue Intelligence Dashboard — NovaTech Solutions

A complete Business Intelligence workflow built in **Amazon QuickSight**: three raw CSV sources cleaned, joined into a unified dataset, and turned into a multi-page interactive dashboard with AI-powered natural language querying (Amazon Q).

**Status:** ✅ Submission Ready & Passed

---

## 📊 Overview

NovaTech Solutions needed a single view across Sales, Marketing, and Customer Support to help VP Sarah Chen make revenue decisions. This project takes three disconnected datasets and turns them into a decision-ready dashboard plus a natural-language Q&A layer.

| Metric | Value |
|---|---|
| Total Deals | 499 (Won: 315 · Lost: 184 · Win Rate: ~63.1%) |
| Marketing Leads | 2,240 (Campaign Response Rate: 27.2%) |
| Support Tickets | 3,000 (Critical Priority: 50) |
| Total Pipeline Deal Value | $100.9M (Unified) / $707.2K (Direct) |
| Total Campaign Spend | $353.51M (Unified) / $12.36M (Direct) |
| Total Support Tickets Volume | 2.79K (Matched to CRM Accounts) |

---

## 🗂 Data Sources

| File | Description |
|---|---|
| `novatech_crm_deals.csv` | Sales opportunities — deal stage, value, rep, region, loss reason |
| `novatech_marketing_campaigns.csv` | Campaign spend, channel, revenue attributed, responses |
| `novatech_support_tickets.csv` | Support tickets — priority, product area, sentiment, downtime |

Reference docs used for context: `novatech_data_dictionary.txt`, `sarah_chen_dashboard_brief.pdf`, `novatech_company_background.pdf`.

---

## 🔧 Step 1 — Data Preparation

- Verified data quality and completeness across all three source files before analysis began.
- Corrected data types (e.g. ticket dates → Date, `users_affected`/`downtime_minutes` → Integer, `error_rate_pct` → Decimal) in `novatech_support_tickets.csv`.
- Added calculated columns:
  - `days_to_close = dateDiff({deal_created_date}, {deal_closed_date}, 'DD')` on the CRM deals table.
  - `campaign_roi = ({revenue_attributed} - {campaign_spend}) / {campaign_spend}` on the marketing campaigns table.
- Built the **NovaTech Unified Dataset**: `novatech_crm_deals.csv` as the anchor table, left-joined to `novatech_marketing_campaigns.csv` and `novatech_support_tickets.csv` on `account_id` (63,420 unified rows).

---

## 📈 Step 2 — Dashboard (3 Sheets)

Built in Amazon QuickSight with cross-filter controls (`sales_region`, `industry`, `deal_stage`, `company_size_tier`, `campaign_channel`, `priority`) on every sheet.

### 1. Marketing Funnel
- **KPIs:** Total Campaign Spend, Total Attributed Revenue, Campaign ROI %, Total Responses & Response Rate (27.2%).
- **Visuals:** Leads by Funnel Stage, Channel Investment vs Attributed Revenue, Monthly Spend vs Revenue Trends, Campaign ROI Ranking, Response Rate by Channel, Spend by Channel.

### 2. Sales Pipeline
- **KPIs:** Total Pipeline Deal Value, Opportunity Count (499), Average Deal Size, Average Deal Closing Time (66.8 Days), Win Rate (63.1%).
- **Visuals:** Deal Value by Pipeline Stage (Won vs Lost), Deal Value by Region, Monthly Pipeline Value Trends, Lost Deals by Loss Reason, Deal Value by Sales Rep, Average Days to Close by Deal Stage.

### 3. Customer Health
- **KPIs:** Total Support Tickets Volume, Avg Tickets per Customer, Total Complaints, Users Affected, Total Downtime Minutes.
- **Visuals:** Ticket Volume by Product Area, Ticket Volume by Customer Sentiment, Ticket Volume by Support Channel, Average Error Rate by Priority, Product Area Impact (Users & Downtime), Ticket Count by Customer Tier, Top 10 At-Risk Accounts Table.

---

## 🤖 Step 3 — AI-Powered Exploration (Amazon Q)

Tested baseline Q accuracy, then configured a QuickSight **Topic** over the unified dataset and re-tested. All 6 verification questions matched the dashboard exactly after Topic configuration:

| # | Knowledge Base | Question | Expected Answer | Q's Answer | Match |
|---|---|---|---|---|---|
| 1 | CRM Deals | How many total deals are there? | 499 | 499 | ✅ Match |
| 2 | CRM Deals | How many deals were Won vs Lost? | Won: 315, Lost: 184 | Won: 315, Lost: 184 | ✅ Match |
| 3 | Marketing | How many total marketing leads are there? | 2,240 | 2,240 | ✅ Match |
| 4 | Marketing | What is the campaign response rate? | 27.2% (609/2240) | 27.2% (609/2240) | ✅ Match |
| 5 | Support | How many total support tickets are there? | 3,000 | 3,000 | ✅ Match |
| 6 | Support | How many tickets are critical priority? | 50 | 50 | ✅ Match |

---

## 📝 Step 4 — Stakeholder Communication

A written business report for VP Sarah Chen (`Sarah_Chen_Stakeholder_Report.md`) translated the dashboard findings into a plain-language narrative — quantified insights, business implications, recommended actions, and an objective note on where the AI (Q) exploration agreed or disagreed with the dashboard.

---

## 🛠 Tools Used

- **Amazon QuickSight** — SPICE datasets, joins, calculated fields, multi-sheet dashboard, filter controls
- **Amazon Q in QuickSight** — Topic configuration, natural language Q&A
- **Python / FastAPI / Chart.js** — Local reproducible interactive dashboard mirror
- Source data: CSV (CRM, Marketing, Support)

---

## 📎 Rubric Coverage

- ✅ Verify data quality and completeness across indexed knowledge bases
- ✅ Transform and join datasets using no-code data preparation tools
- ✅ Design and build a multi-page interactive dashboard for business decision-making
- ✅ Configure and use AI-powered natural language querying to explore data
- ✅ Extract and communicate data-driven business insights to stakeholders

---

## 📂 Submission Deliverables in this Repository

| File | Description |
|---|---|
| `Step 1 - 7a_verification_log.md` | Completed verification log testing pre-indexed knowledge bases and dataset preview |
| `Step 4 - 16_Q_Exploration_Log.md` | Completed Amazon Q exploration log answering 5 questions with reflection |
| `Sarah_Chen_Stakeholder_Report.md` | Executive memo for VP Sarah Chen with findings and recommendations |
| `Marketing_Funnel.pdf` | QuickSight PDF export of Sheet 1 (Marketing Funnel) |
| `Sales_Pipeline.pdf` | QuickSight PDF export of Sheet 2 (Sales Pipeline) |
| `Customer_Health.pdf` | QuickSight PDF export of Sheet 3 (Customer Health) |
| `project-starter-resources.zip` | Archive containing raw datasets, data dictionary, and reference documents |
| `README.md` | Master project documentation |

---

*Built as part of the AWS AI & ML Scholarship / Udacity "Revenue Intelligence Dashboard" project.*
