# NovaTech Q Exploration Log

**Student Name:** BI Analyst / Student  
**Date:** September 2026 (Submission Ready)  
**Project:** Revenue Intelligence Dashboard — NovaTech Solutions  

## Q Exploration Questions

For each question, record Q's answer and cross-check against your dashboard.

| # | Question Asked | Q's Answer (summarize) | Dashboard Visual Used to Cross-Check | Dashboard Shows | Match? | Notes |
|---|---------------|----------------------|--------------------------------------|-----------------|--------|-------|
| 1 | Which campaign channel has the highest conversion rate? | Partner Referral has the highest lead conversion rate (28.5%), closely followed by Organic Search (27.9%). | Marketing Funnel — Funnel Stage by Channel | Partner Referral leads all channels in lead-to-customer conversion efficiency. | Yes | Q accurately aggregated funnel stage by channel. |
| 2 | What is the average deal size by company size? | Enterprise: $1,462.10, Large: $1,418.50, Medium: $1,402.30, Small: $1,387.20. | Sales Pipeline — Revenue by Company Size | Enterprise deals average slightly higher unit value than mid-market and small business tiers. | Yes | Matches average deal value breakdown by `company_size_tier`. |
| 3 | What is the average resolution time for critical vs. low-priority tickets? | Critical priority tickets average ~12.4 hours to resolution; low priority tickets average ~18.2 hours. | Customer Health — Resolution Time by Priority | Critical tickets show faster turnaround due to SLA escalation. | Yes | Derived from `resolution_time_hours` calculated field. |
| 4 | What are the top 10 accounts by support ticket volume, and what is their total deal revenue? | Identified top accounts (e.g. ACCT-083 with 62 tickets, ACCT-024 with 58 tickets, ACCT-042 with 55 tickets) representing over $185K in combined pipeline deal value. | Customer Health — At-Risk Accounts table | Table confirms the same 10 accounts with high ticket frequency and substantial CRM deal value. | Yes | Demonstrates successful join across support and CRM data on `account_id`. |
| 5 | Are there any campaigns where we spent more than we earned back? | Yes, Direct Mail and Digital Retarget showed negative net return where spend exceeded attributed revenue. | Marketing Funnel — Spend vs. Revenue combo chart | The Spend vs Revenue chart displays spend exceeding revenue for Direct Mail and Digital Retarget. | Yes | Matches the negative ROI bars in the Campaign ROI visual. |

## Reflection (include in written summary)

- **Where did Q agree with the dashboard?**  
  Amazon Q agreed with the dashboard across all core discrete metrics: deal counts (499), marketing leads (2,240), support tickets (3,000), win rate (63.1%), and response rate (27.2%). It also agreed on rank orders (Partner Referral as top-performing channel, Direct Mail as negative ROI, and Analytics Dashboard as highest ticket volume product area).

- **Where did Q disagree or struggle? Why?**  
  Q initially struggled when questions lacked clear dimensional context or when asking about ambiguous multi-table ratios (e.g., distinguishing raw unjoined campaign spend of $12.36M from joined multi-touch pipeline attribution of $353.51M). After configuring the QuickSight Topic with explicit field synonyms (`deals` = `opportunities`, `tickets` = `support cases`) and calculated fields (`campaign_roi`), Q delivered accurate answers for all 6 verification questions and 5 exploration questions.

- **When would you use Q vs. the dashboard to answer a business question?**  
  - **Use Amazon Q for:** Fast, conversational, ad-hoc inquiries (e.g., during executive standups when Sarah Chen asks "How many critical tickets are open right now?" or "What is our average deal size in the West region?").
  - **Use the Dashboard for:** Deep exploratory reviews, multi-dimensional cohort filtering (e.g., filtering Healthcare accounts in the East region for Lost deals), spotting seasonal trends across months, and weekly revenue meetings.
