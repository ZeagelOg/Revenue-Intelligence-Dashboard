# NovaTech Data Verification Log

**Student Name:** BI Analyst / Student  
**Date:** September 2026 (Submission Ready)  
**Project:** Revenue Intelligence Dashboard — NovaTech Solutions  

## Instructions

Query each pre-indexed knowledge base using Quick Chat. For each question, record the expected answer (from the data dictionary), Q's actual response, and whether they match. Minimum 6 entries (2 per data knowledge base).

## Verification Log

| # | Knowledge Base | Question Asked | Expected Answer | Q's Actual Answer | Match? | Notes |
|---|----------------|---------------|-----------------|-------------------|--------|-------|
| 1 | NovaTech CRM Deals | How many total deals are there? | 499 | 499 | Yes | Verified in `novatech_crm_deals.csv`. Represents all closed deals (won + lost). |
| 2 | NovaTech CRM Deals | How many deals were Won vs Lost? | Won: 315, Lost: 184 | Won: 315, Lost: 184 | Yes | Exact split. Win rate is 63.1% (315/499). |
| 3 | NovaTech Marketing Campaigns | How many total marketing leads are there? | 2,240 | 2,240 | Yes | Matches total lead rows in `novatech_marketing_campaigns.csv`. |
| 4 | NovaTech Marketing Campaigns | What is the campaign response rate? | 27.2% (609/2240) | 27.2% (609/2240) | Yes | 609 responded leads out of 2,240 total leads. |
| 5 | NovaTech Support Tickets | How many total support tickets are there? | 3,000 | 3,000 | Yes | Complete ticket records from June 2023 to February 2025. |
| 6 | NovaTech Support Tickets | How many tickets are critical priority? | 50 | 50 | Yes | 50 critical tickets out of 3,000 total (1.67%). |
| 7 | NovaTech Reference Documents | What is the primary join key connecting all three datasets? | account_id | account_id | Yes | Confirmed across data dictionary and company brief. |

## Cross-Check

Pick one fact from above and confirm it independently in the QuickSight dataset preview.

- **Fact verified:** Support Ticket Priority Distribution
- **Chat said:** Low: 1,500; Medium: 1,050; High: 400; Critical: 50. Total: 3,000.
- **QuickSight shows:** In the dataset preview of `novatech_support_tickets`, filtering by `priority` returns 1,500 low, 1,050 medium, 400 high, and 50 critical rows.
- **Consistent?** Yes, 100% consistent across Quick Chat and the QuickSight dataset preview.
