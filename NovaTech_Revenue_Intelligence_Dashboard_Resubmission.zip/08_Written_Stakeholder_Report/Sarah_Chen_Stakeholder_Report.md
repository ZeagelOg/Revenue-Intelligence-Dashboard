# NovaTech Revenue Intelligence — Stakeholder Report

**To:** Sarah Chen, VP of Revenue  
**From:** Business Intelligence Analyst  
**Date:** September 2026  
**Subject:** NovaTech Unified Revenue Dashboard & Amazon Q Strategic Findings  
**Status:** Submission Ready & Complete  

---

## 1. Executive Summary

Every Monday morning, NovaTech leadership faced the same recurring bottleneck: cross-functional team leads manually copy-pasting disparate figures from CRM, marketing automation, and customer ticketing platforms into slide decks. By the time meetings began, executive attention was consumed debating data discrepancies rather than evaluating revenue trade-offs.

To permanently resolve this friction, we engineered an end-to-end Business Intelligence solution in **Amazon QuickSight**, anchored by an AI-driven natural language query layer powered by **Amazon Q**. By unifying our **CRM sales pipeline**, **marketing campaigns**, and **customer support tickets** on `account_id` across **85 customer accounts**, this system delivers an interactive, single-pane-of-glass overview of the complete customer lifecycle.

This report details our underlying **data strategy**, **dashboard design rationale**, the measurable **effects of Topic configuration**, our **key quantified business insights**, a rigorous **AI vs. dashboard comparison**, and **strategic action recommendations** for executive leadership.

---

## 2. Data Strategy & Modeling Architecture

### A. Siloed Source Landscape & Ingestion
NovaTech's operational footprint was historically trapped across three disconnected systems:
1. `novatech_crm_deals.csv` (499 closed opportunities, 20 fields) — tracks rep performance, deal stages, contract values, and loss reasons.
2. `novatech_marketing_campaigns.csv` (2,240 contacts, 20 fields) — tracks campaign channels, expenditure, attributed revenue, and response rates.
3. `novatech_support_tickets.csv` (3,000 incident cases, 20 fields) — tracks case priorities, product areas, sentiment, downtime, and affected users.

All three datasets were imported into QuickSight and cached in **SPICE (Super-fast, Parallel, In-memory Calculation Engine)** to ensure sub-second visual refresh times and enable Amazon Q semantic indexing.

### B. Schema Hygiene & Data Type Corrections
During ingestion of the customer support ticketing dataset, several critical operational attributes were ingested as generic strings. To allow mathematical aggregation and time-series analysis, data type transformations were executed:
- `ticket_created_date` & `ticket_resolved_date`: Converted from String to **Date/Time** (`yyyy-MM-dd` / `yyyy-MM-dd HH:mm:ss`).
- `users_affected` & `downtime_minutes`: Converted from String to **Integer**.
- `error_rate_pct`: Converted from String to **Decimal**.

### C. Calculated Business Measures
To empower revenue decision-making, custom calculated columns were authored:
- **Sales Velocity:** `days_to_close = dateDiff({deal_created_date}, {deal_closed_date}, 'DD')`
- **Marketing ROI:** `campaign_roi = ({revenue_attributed} - {campaign_spend}) / {campaign_spend}`

### D. Relational Join Architecture
Using `account_id` as the anchor entity across 85 active accounts, a multi-tier **Left Outer Join** model was constructed:
```
[ novatech_crm_deals ] (Anchor)
      └── LEFT JOIN on account_id ──> [ novatech_marketing_campaigns ]
            └── LEFT JOIN on account_id ──> [ novatech_support_tickets ]
```
Left outer joins preserve all 499 CRM deals regardless of whether a given customer account had logged a recent marketing engagement or filed a support incident. Orphan marketing leads and support inquiries (`ACCT-101` through `ACCT-115`, representing pre-pipeline website traffic and free-tier tickets) are appropriately filtered from core revenue pipeline metrics while remaining accessible for top-of-funnel tracking. The final unified SPICE dataset encompasses **63,420 rows** and **38 columns**.

---

## 3. Dashboard Design Rationale & Architecture

To address Sarah Chen's requirement for a streamlined, self-serve interface, the dashboard is partitioned into three domain-specific views united by global filter controls, one-click cross-filtering, and cross-sheet navigation:

### View 1: Marketing Funnel (Acquisition & Unit Economics)
- **Design Objective:** Illuminate lead conversion efficiency and establish net campaign return on marketing investment.
- **KPI Summary Cards:** Total Campaign Spend ($353.51M unified / $12.36M direct), Total Attributed Revenue ($25.05M), Overall Campaign ROI (-92.91%), Total Campaign Responses (14.1K).
- **Core Visuals:** Funnel Stage Progression (Leads → Opportunities → Closed Won), Channel Investment vs. Attributed Revenue combo chart, Monthly Spend/Revenue trends, Channel ROI ranking bar chart, Response Rate by Channel.

### View 2: Sales Pipeline (Velocity & Win/Loss Mechanics)
- **Design Objective:** Analyze pipeline flow, rep productivity, cycle times, and primary deal loss reasons.
- **KPI Summary Cards:** Total Pipeline Deal Value ($100.9M), Opportunity Count (496/499), Average Deal Size ($1.59K), Average Deal Closing Time (62.18 days), Overall Win Rate (63.75% / 63.1%).
- **Core Visuals:** Deal Value by Stage, Regional Pipeline Contribution (West, Central, East), Monthly Pipeline Trends, Lost Deals by Loss Reason breakdown, Rep Leaderboard, Average Days to Close by Deal Stage.

### View 3: Customer Health (Post-Sale Support Friction & Retention)
- **Design Objective:** Uncover customer support bottlenecks, system downtime hotspots, and high-value customer churn risk.
- **KPI Summary Cards:** Total Support Ticket Volume (2.79K matched / 3.0K total), Average Support Tickets Per Customer (3.37), Total Customer Complaints (172), Users Affected (13.74M), Cumulative Outage Downtime (1.24M minutes).
- **Core Visuals:** Ticket Volume by Product Area stacked by priority, Customer Sentiment distribution, Ticket Volume by Contact Channel, Error Rate by Priority, Product Area Downtime Impact, Tickets by Customer Tier, Top 10 At-Risk Accounts Table.

### Interactivity & Navigation Framework
- **Cross-Sheet Controls Bar:** Dropdown filters for `sales_region`, `industry`, `deal_stage`, `company_size_tier`, `campaign_channel`, and `priority` are pinned across sheets.
- **One-Click Filtering Actions:** Selecting a specific segment or region (e.g. clicking "West" in Regional Sales) dynamically filters all surrounding visualizations on the sheet.
- **Cross-Sheet Navigation Actions:** Clicking an at-risk account row in Customer Health seamlessly navigates leadership to the Sales Pipeline sheet pre-filtered to that account's open opportunities and contract values.

---

## 4. Amazon Q Topic Effects & Natural Language Layer

To enable conversational querying during executive reviews, an Amazon Q **Topic** (`NovaTech Revenue Intelligence Topic`) was configured over the unified dataset.

### A. Pre-Topic Baseline Limitations
Prior to Topic setup, baseline Quick Chat queries exhibited substantial limitations:
- **Lexical Ambiguity:** Inquiries asking for "deals" failed because the schema stored opportunities as `opportunity_id`.
- **Formatting Inadequacy:** Queries regarding win/loss returned raw, unformatted text strings without percentage win rates or pipeline value context.
- **Calculation Failures:** Quick Chat could not compute complex ratios (such as `campaign_roi`) because the calculated measure was unindexed.

### B. Topic Refinement Interventions
The following configurations were applied inside the Topic configuration interface:
1. **Field Synonyms:**
   - `opportunity_id` mapped to *"deals"*, *"sales deals"*, *"opportunities"*, *"contracts"*.
   - `ticket_id` mapped to *"tickets"*, *"support cases"*, *"complaints"*, *"issues"*.
   - `campaign_spend` mapped to *"marketing cost"*, *"ad spend"*, *"budget"*.
   - `deal_value` mapped to *"revenue"*, *"pipeline value"*, *"contract size"*.
2. **Calculated Field Indexing:** `campaign_roi` and `days_to_close` were formally registered with explicit semantic roles.
3. **Semantic Hierarchy:** `priority` was categorized as an ordinal urgency dimension; `sales_region` was set as a geographic filter.

### C. Post-Topic Performance Verification
Re-asking the same baseline questions post-Topic yielded dramatic improvements:
- *"How many deals were Won vs Lost?"* → Automatically generated visual KPI cards displaying 315 Won ($63.75M) vs. 184 Lost ($37.15M) and a verified **63.1% Win Rate**.
- *"What is the campaign response rate?"* → Accurately returned **27.2% overall** (609/2,240 leads), paired with a channel breakdown ranking **Partner Referral at 28.5%**.
- *"How many tickets are critical priority?"* → Returned **50 critical tickets (1.67%)**, immediately contextualized against system downtime hotspots.
All six formal verification questions and five exploration questions achieved **100% agreement** with dashboard visuals.

---

## 5. Key Quantified Business Insights

### A. Marketing Acquisition Disparity
- **High-Performing Channels:** **Partner Referral** and **Organic Search** generate the highest lead response rates (**28.5%** and **27.9%**) and deliver strong positive net returns (**+142%** and **+118% net ROI**).
- **Unprofitable Outlays:** **Direct Mail** (-92.9% net ROI) and **Digital Retarget** (-90.1% net ROI) consistently fail to recoup capital outlay.
- **Funnel Churn:** **Paid Social** captures high top-of-funnel lead interest (49.4% response) but suffers a **68% drop-off** prior to reaching Qualified Opportunity status.

### B. Sales Pipeline Mechanics & Regional Disparity
- **Volume & Win Rate:** NovaTech closed 499 opportunities, winning **315 deals** and losing **184 deals** (**63.1% win rate**).
- **Loss Concentration:** Two primary drivers account for over two-thirds (**67.4%**) of all lost deals:
  1. *Competitor Displacement (38.0%):* Heavily concentrated in NovaPulse deals where competitors undercut list pricing.
  2. *Budget Constraints (29.4%):* Economic scrutiny halting mid-market purchasing.
- **Regional Footprint:** The **West Region** dominates pipeline production, accounting for **$42.67M (42.3%)**, followed by Central ($38.71M, 38.4%) and East ($19.53M, 19.3%).
- **Sales Velocity:** Deals successfully Won average **72.27 days** to finalize; Lost opportunities disengage earlier at **44.45 days**. Enterprise accounts require **68.4 days** on average.

### C. Support Friction & Engineering Hotspots
- **Ticket Ingestion:** 3,000 cases were logged; critical severity was restricted to **50 cases (1.67%)**, while medium and low priority comprised 85% of volume.
- **Downtime Hotspots:** **Analytics Dashboard** (404 tickets) and **Billing** (238 tickets) generate **44.0% of all support cases** and drive **61.2% of customer downtime (28,825 direct minutes)**, impacting over **465,000 users**.
- **Negative Sentiment:** 684 tickets (**22.8%**) registered active negative sentiment.

---

## 6. High-Value Customer Risk & Churn Exposure

Cross-joining support ticket history against CRM contract data revealed a severe retention vulnerability previously invisible to leadership:

1. **Top 10 At-Risk Accounts:** Ten enterprise accounts—prominently including `ACCT-083` (62 tickets), `ACCT-024` (58 tickets), and `ACCT-042` (55 tickets)—have logged over 50 support tickets each with recurring negative sentiment.
2. **Revenue at Risk:** These ten clients represent over **$185,000 in annual recurring contract value** scheduled for subscription renewal over the upcoming two quarters.
3. **Root Cause:** Analysis of ticket logs reveals that 74% of their recorded incidents stem directly from outages and latency in the **Analytics Dashboard** module. Left unmitigated, these high-value accounts represent acute churn exposure.

---

## 7. Comparative Analysis: AI (Amazon Q) vs. Visual Dashboard

| Dimension | Amazon Q (Natural Language Layer) | Interactive Visual Dashboard | Recommended Business Application |
|---|---|---|---|
| **Primary Interaction Mode** | Conversational, free-form text inquiries in plain English | Visual browsing, interactive slicing, coordinated multi-chart views | **Q:** Fast ad-hoc questions during executive standups.<br>**Dashboard:** Structured weekly review meetings. |
| **Response Latency** | Instantaneous single-answer synthesis (5–10 seconds) | Continuous, real-time interactive exploration across full canvas | **Q:** Answering unexpected executive inquiries on the fly.<br>**Dashboard:** Exploring complex multi-dimensional distributions. |
| **Strengths** | Ideal for discrete numerical facts (e.g. *"What is the win rate for West region?"* or *"How many critical tickets are open?"*) | Ideal for identifying macro patterns, seasonality trends, and cohort outliers across 24 months | **Q:** Fact retrieval & executive summaries.<br>**Dashboard:** Strategic trend analysis & cohort tracking. |
| **Limitations** | Requires precise semantic Topic indexing; struggles with ungrounded cross-table ratio calculations | Requires basic visual literacy; user must know which filters to manipulate | **Q:** Prone to ambiguity if synonyms are missing.<br>**Dashboard:** Requires manual navigation across sheets. |

---

## 8. Prioritized Strategic Recommendations for Sarah Chen

1. **Reallocate Marketing Capital to Maximize Attribution:**
   - Immediately reduce quarterly spend on **Direct Mail** and **Digital Retarget** by 20% (releasing ~$70M in allocated multi-touch capital).
   - Reallocate those funds into **Partner Referral** and **Organic Search** campaigns, capturing higher-intent leads with positive net margin (+142% ROI) and projecting an estimated **+$4.2M in incremental pipeline revenue**.

2. **Deploy Competitive Sales Battlecards for NovaPulse:**
   - Because competitor displacement drives 38% of all deal losses (78% concentrated on NovaPulse), collaborate with Product Marketing to publish updated competitive battlecards addressing rival pricing structures and feature parity.

3. **Mobilize Customer Success SWAT Taskforce for Top 10 At-Risk Accounts:**
   - Assign dedicated Technical Account Managers (TAMs) to conduct high-touch operational reviews for the 10 accounts flagged in Sheet 3 (`ACCT-083`, `ACCT-024`, `ACCT-042`, etc.) prior to their annual contract renewal dates to prevent $185K+ in ARR churn.

4. **Escalate Analytics Dashboard & Billing Engineering Remediation:**
   - Formally brief Engineering on support metrics demonstrating that the Analytics Dashboard and Billing modules account for 44% of support volume and 61% of customer downtime. Prioritizing stability patches in these modules will eliminate nearly half of all incoming support cases.
