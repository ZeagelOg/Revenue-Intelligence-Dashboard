# NovaTech Dashboard — Interactive Controls & Actions Evidence

This document provides visual evidence and configuration specifications for the interactive controls, cross-visual filtering actions, and cross-sheet navigation actions built in **Amazon QuickSight**. Because static PDF exports only render visual states at print time and flatten dynamic controls into footer text, this guide provides complete architectural proof.

---

## 1. Interactive Filter Controls (Across All 3 Sheets)
*Rubric Requirement: "At least two sheets include interactive filter controls."*

Each of the three dashboard sheets features a dedicated, pinned **Controls Bar** positioned directly below the top navigation tabs:

- **Filter 1 — Sales Region:** Dropdown parameter filtering (`sales_region` = Central, East, West).
- **Filter 2 — Industry:** Multi-select control (`industry` = Financial Services, Healthcare, Technology, etc.).
- **Filter 3 — Deal Stage:** Dropdown control (`deal_stage` = Won, Lost).
- **Filter 4 — Company Size Tier:** Segment filter (`company_size_tier` = Enterprise, Large, Medium, Small).
- **Filter 5 — Campaign Channel:** Marketing channel control (`campaign_channel` = Direct Mail, Email, Organic Search, Paid Social, Partner Referral).
- **Filter 6 — Support Priority:** Severity filter (`priority` = low, medium, high, critical).

### Evidence Details:
1. **Interactive Dropdown Active:** `Evidence_01_Interactive_Filter_Controls_Active.png` displays the `sales_region` dropdown open with `West` selected.
2. **Analysis Views:**
   - `Marketing_Funnel_Analysis_View.jpg` (Shows Controls bar across Marketing Funnel)
   - `Sales_Pipeline_Analysis_View.jpg` (Shows Controls bar across Sales Pipeline)
   - `Customer_Health_Analysis_View.jpg` (Shows Controls bar across Customer Health)

---

## 2. One-Click Filtering Action on Multiple Visuals
*Rubric Requirement: "At least one sheet includes a one-click filtering action on two or more visuals."*

On **Sheet 2 (Sales Pipeline)**, a one-click cross-filtering action is enabled on the `Total Deal Value by Region` visual:

### Action Configuration Details:
- **Action Name:** `Filter other visuals on sheet (One-Click)`
- **Activation Event:** `Select` (Single click on any bar, slice, or datapoint)
- **Action Type:** `Filter same-sheet visuals`
- **Target Visuals:** `All visuals on this sheet`
- **Impacted Visuals:**
  1. `Total Deal Value by Pipeline Stage` (Won vs Lost distribution)
  2. `Monthly Pipeline Value Trends` (Time series trend)
  3. `Lost Deals by Loss Reason` (Loss reason breakdown pie)
  4. `Total Deal Value by Sales Rep` (Rep ranking horizontal bar)
  5. `Average Days to Close by Deal Stage` (Closing velocity)

*Evidence Screenshot:* `Evidence_02_One_Click_Filtering_Action.png` displays the QuickSight modal verifying the action name, select activation trigger, same-sheet action type, and multi-visual target list.

---

## 3. Cross-Sheet Navigation Action
*Rubric Requirement: "At least one cross-sheet navigation action links between sheets."*

To satisfy Sarah Chen's requirement of tracing high-friction support accounts into sales pipeline deal values, a **Cross-Sheet Navigation Action** links **Sheet 3 (Customer Health)** directly to **Sheet 2 (Sales Pipeline)**.

### Action Configuration Details:
- **Source Visual:** `Top 10 At-Risk Accounts Table` / `Product Area Impact` on Sheet 3
- **Action Name:** `Navigate to Sales Pipeline by Account`
- **Activation Event:** `Select` (Clicking an account row or identifier)
- **Action Type:** `Navigation action`
- **Target Sheet:** `Sheet 2: Sales Pipeline`
- **Parameter Mapping:** `account_id` → transferred to target parameter `account_id`
- **User Workflow:** When leadership clicks on an at-risk enterprise customer (e.g. `ACCT-083` with 62 tickets and negative sentiment), QuickSight automatically opens the Sales Pipeline sheet pre-filtered to `ACCT-083`, displaying that account's open deals, reps assigned, and contract renewal timeline.

*Evidence Screenshot:* `Evidence_03_Cross_Sheet_Navigation_Action.png` displays the QuickSight navigation action modal with target sheet specification and parameter binding.
