# Submission Checklist & Rubric Mapping

This checklist matches the classroom instructions and verifies that every required rubric deliverable is included in this package.

## Classroom Submission Checklist Verification

- [x] **Verification log** — at least 6 entries covering all three knowledge bases, using the provided markdown template or equivalent structured format.
  - *Location:* `01_Verification_Log/Step 1 - 7a_verification_log.md`
  - *Status:* Complete. Contains 7 entries covering CRM Deals, Marketing Campaigns, Support Tickets, and Reference Documents, plus cross-check. Visual table screenshots `01_Verification_Log_Table_Part1.jpg` and `02_Verification_Log_Table_Part2.jpg` included.

- [x] **Data transformation screenshots** — join diagram, join configuration, calculated fields, and data type corrections.
  - *Location:* `02_Data_Transformation_Screenshots/`
  - *Status:* Complete.
    - `01_SPICE_Datasets_Overview_Rows_Columns.png`: Shows all 3 CSV sources + unified dataset imported into SPICE with exact row & column counts.
    - `02_SPICE_Datasets_Manage_Data.jpg`: SPICE status verification inside QuickSight.
    - `03_Data_Type_Corrections_Support_Tickets.jpg`: Shows 9 columns converted (Date, Integer, Decimal).
    - `04_Calculated_Field_CRM_Days_To_Close.jpg`: `days_to_close = dateDiff({deal_created_date}, {deal_closed_date}, 'DD')`.
    - `05_Calculated_Field_Marketing_Campaign_ROI.jpg`: `campaign_roi = ({revenue_attributed} - {campaign_spend}) / {campaign_spend}`.
    - `06_Unified_Dataset_Join_Diagram_and_Config.jpg`: Full multi-tier Left outer join diagram and join key configuration (`account_id.1 = account_id`).
    - `Data_Transformation_Documentation.md`: Complete architectural guide.

- [x] **Dashboard PDF export** — all 3 sheets (Marketing Funnel, Sales Pipeline, Customer Health).
  - *Location:* `03_Dashboard_PDF_Exports/`
  - *Status:* Complete.
    - `Marketing_Funnel.pdf`: QuickSight PDF export of Sheet 1.
    - `Sales_Pipeline.pdf`: QuickSight PDF export of Sheet 2.
    - `Customer_Health.pdf`: QuickSight PDF export of Sheet 3.
    - `Marketing_Funnel_Analysis_View.jpg`: High-res analysis canvas view showing KPIs and controls.
    - `Sales_Pipeline_Analysis_View.jpg`: High-res analysis canvas view showing KPIs and controls.
    - `Customer_Health_Analysis_View.jpg`: High-res analysis canvas view showing KPIs and controls.
    - `Evidence_01_Interactive_Filter_Controls_Active.png`: Verification of interactive controls bar and dropdown.
    - `Evidence_02_One_Click_Filtering_Action.png`: QuickSight modal proving one-click filtering action on multiple visuals.
    - `Evidence_03_Cross_Sheet_Navigation_Action.png`: QuickSight modal proving cross-sheet navigation linking between sheets.
    - `Interactive_Controls_and_Actions_Evidence.md`: Complete explanatory documentation.

- [x] **Before/after Topic screenshots** — baseline Q responses and post-Topic Q responses for the same 2–3 questions.
  - *Location:* `04_Before_After_Topic_Screenshots/`
  - *Status:* Complete.
    - `01_Baseline_Quick_Chat_Interaction.jpg`: Baseline Q questions & response before Topic configuration.
    - `02_Amazon_Q_Topic_Configuration.png`: QuickSight Topic configuration setup with linked dataset, 10 synonyms, and measures.
    - `03_Post_Topic_Quick_Chat_Responses.png`: Grounded visual comparison for the 3 baseline questions re-asked post-Topic.
    - `04_Assistant_Workspace_Overview.jpg`: QuickSight Q assistant interface with session history.
    - `Before_After_Topic_Comparison.md`: Side-by-side comparative analysis.

- [x] **Q Exploration Log** — at least 5 entries spanning all three data domains with questions, Q responses, and dashboard verification.
  - *Location:* `05_Q_Exploration_Log/Step 4 - 16_Q_Exploration_Log.md`
  - *Status:* Complete. Covers 5 business questions across Marketing, Sales, and Support, dashboard visual cross-checks, match status, and in-depth reflection.

- [x] **Dashboard executive summary text** — auto-generated from the published dashboard.
  - *Location:* `06_Dashboard_Executive_Summary/`
  - *Status:* Complete.
    - `Dashboard_Executive_Summary.txt`: Plain text executive narrative auto-generated from the published QuickSight dashboard.
    - `Dashboard_Executive_Summary.md`: Formatted markdown version.

- [x] **Annotated dashboard screenshots** — showing 3–5 text annotations on your dashboard sheets.
  - *Location:* `07_Annotated_Dashboard_Screenshots/`
  - *Status:* Complete. Contains 5 distinct, high-contrast text annotations placed directly on dashboard sheets:
    - `01_Marketing_Funnel_Annotated_Dashboard.png`: Annotation 1 (Campaign ROI Disparity & Budget Shift) & Annotation 2 (Conversion Velocity & Lead Progression).
    - `02_Sales_Pipeline_Annotated_Dashboard.png`: Annotation 3 (Primary Loss Drivers & Competitor Risk) & Annotation 4 (Regional Pipeline Concentration).
    - `03_Customer_Health_Annotated_Dashboard.png`: Annotation 5 (High-Value At-Risk Accounts & Product Downtime Hotspots).
    - `Annotated_Dashboard_Summary.md`: Full text and strategic analysis of all 5 annotations.

- [x] **Written report for VP Sarah Chen** — 1–3 pages covering data strategy, design rationale, Topic effects, key insights, and AI comparison.
  - *Location:* `08_Written_Stakeholder_Report/Sarah_Chen_Stakeholder_Report.md`
  - *Status:* Complete. Rigorous 8-section executive memo explicitly covering all 5 rubric areas in depth.
