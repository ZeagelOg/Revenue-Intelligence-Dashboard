# Revenue Intelligence Dashboard — NovaTech Solutions
## Complete Udacity Resubmission Package

This package contains the complete, restructured submission for the **Revenue Intelligence Dashboard for NovaTech Solutions** capstone project (AWS AI & ML Scholarship / Udacity). 

All project deliverables and visual evidence have been regrouped into **8 dedicated subfolders** following the classroom submission checklist and addressing every item cited in the reviewer's feedback.

---

## 🗂 Submission Package Directory Structure

```
novatech_resubmission_package/
│
├── README.md                                          <-- Master project documentation & rubric mapping
├── SUBMISSION_CHECKLIST.md                            <-- Completed itemized checklist
│
├── 01_Verification_Log/
│   ├── Step 1 - 7a_verification_log.md                <-- 7 verification entries across CRM, Mkt, Support + cross-check
│   ├── 01_Verification_Log_Table_Part1.jpg            <-- Baseline Q verification table screenshot (part 1)
│   └── 02_Verification_Log_Table_Part2.jpg            <-- Baseline Q verification table screenshot (part 2)
│
├── 02_Data_Transformation_Screenshots/
│   ├── 01_SPICE_Datasets_Overview_Rows_Columns.png    <-- All 3 CSV sources + unified in SPICE with row/col counts
│   ├── 02_SPICE_Datasets_Manage_Data.jpg              <-- QuickSight Manage Data modal (SPICE status)
│   ├── 03_Data_Type_Corrections_Support_Tickets.jpg   <-- QuickSight Change Data Type (9 columns: Date, Int, Dec)
│   ├── 04_Calculated_Field_CRM_Days_To_Close.jpg      <-- dateDiff({deal_created_date}, {deal_closed_date}, 'DD')
│   ├── 05_Calculated_Field_Marketing_Campaign_ROI.jpg <-- ({revenue_attributed} - {campaign_spend}) / {campaign_spend}
│   ├── 06_Unified_Dataset_Join_Diagram_and_Config.jpg <-- Visual join diagram, Left outer join on account_id
│   └── Data_Transformation_Documentation.md           <-- Full data dictionary & transformation methodology
│
├── 03_Dashboard_PDF_Exports/
│   ├── Marketing_Funnel.pdf                           <-- QuickSight PDF export of Sheet 1
│   ├── Sales_Pipeline.pdf                             <-- QuickSight PDF export of Sheet 2
│   ├── Customer_Health.pdf                            <-- QuickSight PDF export of Sheet 3
│   ├── Marketing_Funnel_Analysis_View.jpg             <-- High-res analysis canvas view showing KPIs and controls
│   ├── Sales_Pipeline_Analysis_View.jpg               <-- High-res analysis canvas view showing KPIs and controls
│   ├── Customer_Health_Analysis_View.jpg              <-- High-res analysis canvas view showing KPIs and controls
│   ├── Evidence_01_Interactive_Filter_Controls_Active.png <-- Pinned controls bar & dropdown selection in action
│   ├── Evidence_02_One_Click_Filtering_Action.png     <-- QuickSight Action modal: one-click cross-filtering
│   ├── Evidence_03_Cross_Sheet_Navigation_Action.png  <-- QuickSight Action modal: cross-sheet navigation
│   └── Interactive_Controls_and_Actions_Evidence.md   <-- Documentation of filters and interactive actions
│
├── 04_Before_After_Topic_Screenshots/
│   ├── 01_Baseline_Quick_Chat_Interaction.jpg         <-- Baseline Q queries before Topic configuration
│   ├── 02_Amazon_Q_Topic_Configuration.png            <-- QuickSight Topic setup (synonyms, semantics, measures)
│   ├── 03_Post_Topic_Quick_Chat_Responses.png         <-- Post-Topic improved visual responses for baseline questions
│   ├── 04_Assistant_Workspace_Overview.jpg            <-- Assistant interface overview
│   └── Before_After_Topic_Comparison.md               <-- Side-by-side audit of Q accuracy improvement
│
├── 05_Q_Exploration_Log/
│   └── Step 4 - 16_Q_Exploration_Log.md               <-- 5 exploration questions across domains + reflection
│
├── 06_Dashboard_Executive_Summary/
│   ├── Dashboard_Executive_Summary.txt                <-- Plain text narrative auto-generated from dashboard
│   └── Dashboard_Executive_Summary.md                 <-- Markdown formatted executive summary
│
├── 07_Annotated_Dashboard_Screenshots/
│   ├── 01_Marketing_Funnel_Annotated_Dashboard.png    <-- Sheet 1 with Annotation 1 & Annotation 2
│   ├── 02_Sales_Pipeline_Annotated_Dashboard.png      <-- Sheet 2 with Annotation 3 & Annotation 4
│   ├── 03_Customer_Health_Annotated_Dashboard.png     <-- Sheet 3 with Annotation 5
│   └── Annotated_Dashboard_Summary.md                 <-- Text and strategic breakdown of all 5 annotations
│
└── 08_Written_Stakeholder_Report/
    └── Sarah_Chen_Stakeholder_Report.md               <-- Comprehensive 8-section report for VP Sarah Chen
```

---

## 📋 Rubric Compliance & Reviewer Feedback Matrix

| # | Reviewer Feedback Item | Rubric Deliverable | Where to Find in Resubmission |
|---|---|---|---|
| **1** | *"Screenshots show all three CSV datasets successfully imported into SPICE with correct row counts and column counts."* | Data Ingestion | `02_Data_Transformation_Screenshots/01_SPICE_Datasets_Overview_Rows_Columns.png` (CRM: 499r/20c; Mkt: 2,240r/20c; Support: 3,000r/20c). |
| **2** | *"Screenshots show data type corrections applied to at least one dataset."* | Schema Correction | `02_Data_Transformation_Screenshots/03_Data_Type_Corrections_Support_Tickets.jpg` (9 columns converted: Date, Int, Decimal). |
| **3** | *"A unified dataset joins all three data sources on a shared key, with the join diagram and join configuration visible in screenshots."* | Data Modeling | `02_Data_Transformation_Screenshots/06_Unified_Dataset_Join_Diagram_and_Config.jpg` (CRM -> Mkt -> Support Left Join on `account_id.1 = account_id`). |
| **4** | *"All four datasets (three source + one unified) are saved to SPICE."* | SPICE Ingestion | `02_Data_Transformation_Screenshots/01_SPICE_Datasets_Overview_Rows_Columns.png` and `02_SPICE_Datasets_Manage_Data.jpg`. |
| **5** | *"Each sheet includes at least one KPI summary card and multiple visualizations appropriate to the business questions."* | Dashboard Architecture | `03_Dashboard_PDF_Exports/` (3 PDFs + 3 Analysis Screenshots showing 4–5 KPIs and 6–7 visuals per sheet). |
| **6** | *"At least two sheets include interactive filter controls. (Evidence of that missing from PDF files)"* | Interactivity | `03_Dashboard_PDF_Exports/Evidence_01_Interactive_Filter_Controls_Active.png` and analysis screenshots showing the pinned Controls bar. |
| **7** | *"At least one sheet includes a one-click filtering action on two or more visuals. (Evidence of that missing from PDF files)"* | Visual Cross-Filtering | `03_Dashboard_PDF_Exports/Evidence_02_One_Click_Filtering_Action.png` (QuickSight Action modal showing Select trigger on all visuals). |
| **8** | *"At least one cross-sheet navigation action links between sheets. (Evidence of that missing from PDF files)"* | Cross-Sheet Navigation | `03_Dashboard_PDF_Exports/Evidence_03_Cross_Sheet_Navigation_Action.png` (QuickSight Action modal linking Customer Health to Sales Pipeline). |
| **9** | *"Screenshots show baseline Quick Chat interaction (2–3 questions asked before Topic configuration)."* | AI Baseline | `04_Before_After_Topic_Screenshots/01_Baseline_Quick_Chat_Interaction.jpg`. |
| **10** | *"A Topic is configured, and screenshots show the Topic setup."* | Amazon Q Topic Setup | `04_Before_After_Topic_Screenshots/02_Amazon_Q_Topic_Configuration.png` (Topic configured on Unified dataset with 10 synonyms and measures). |
| **11** | *"Post-Topic screenshots show the same 2–3 baseline questions re-asked with improved or changed responses."* | Post-Topic Verification | `04_Before_After_Topic_Screenshots/03_Post_Topic_Quick_Chat_Responses.png` & `Before_After_Topic_Comparison.md`. |
| **12** | *"Dashboard includes 3–5 text annotations visible on the dashboard sheets (Not included)."* | Visual Insights | `07_Annotated_Dashboard_Screenshots/` (3 high-res annotated sheets featuring **5 distinct text annotations**). |
| **13** | *"Dashboard executive summary text — auto-generated from the published dashboard."* | Executive Narrative | `06_Dashboard_Executive_Summary/Dashboard_Executive_Summary.txt` & `.md`. |
| **14** | *"Please regroup your files into subfolders following the submission check list."* | Submission Packaging | Regrouped into **8 canonical subfolders** matching the classroom checklist exactly. |

---

## 📊 Summary of Key Quantified Findings for VP Sarah Chen

1. **Marketing ROI Disparity:**
   - **Partner Referral** and **Organic Search** deliver positive net returns (**+142%** and **+118% net ROI**; 28.5% and 27.9% response rates).
   - **Direct Mail** (-92.9% ROI) and **Digital Retarget** (-90.1% ROI) lose money. Reallocating 20% budget (~$70M allocated) to Partner Referrals is projected to yield **+$4.2M** in incremental revenue.
2. **Sales Pipeline & Loss Factors:**
   - Total pipeline value is **$100.9M** across 499 closed opportunities with an overall **63.1% Win Rate** (315 Won vs. 184 Lost).
   - **Competitor displacement (38%)** and **budget constraints (29%)** account for two-thirds of all deal losses ($37.15M lost pipeline).
   - **West Region** leads pipeline generation at **$42.67M (42.3%)**.
3. **Customer Support Hotspots & High-Value Account Churn Risk:**
   - **Analytics Dashboard** (404 tickets) and **Billing** (238 tickets) generate 44% of ticket volume and **61.2% of customer downtime (28,825 mins)**.
   - **Top 10 at-risk enterprise accounts** (including `ACCT-083`, `ACCT-024`, `ACCT-042`) have filed 55+ tickets each with negative sentiment, placing over **$185,000 in annual recurring revenue** at immediate risk of churn.
