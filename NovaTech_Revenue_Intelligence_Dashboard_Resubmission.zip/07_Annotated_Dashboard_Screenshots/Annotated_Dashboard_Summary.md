# NovaTech Dashboard — Annotated Dashboard Screenshots Summary

*Rubric Requirement: "Dashboard includes 3–5 text annotations visible on the dashboard sheets."*

This folder contains high-resolution annotated dashboard screenshots for each of the three sheets in the **NovaTech Revenue Intelligence Dashboard**, displaying **5 distinct text callout annotations** that highlight critical data-driven business insights for VP Sarah Chen.

---

## Annotated Dashboard Files in this Directory

| File Name | Sheet | Annotations Included | Focus Area |
|---|---|---|---|
| `01_Marketing_Funnel_Annotated_Dashboard.png` | **Marketing Funnel** | **Annotation 1** & **Annotation 2** | Campaign ROI Disparity & Lead Conversion Progression |
| `02_Sales_Pipeline_Annotated_Dashboard.png` | **Sales Pipeline** | **Annotation 3** & **Annotation 4** | Primary Loss Drivers & Regional Pipeline Concentration |
| `03_Customer_Health_Annotated_Dashboard.png` | **Customer Health** | **Annotation 5** | High-Value At-Risk Accounts & Product Downtime Hotspots |

---

## Detailed Text of the 5 Dashboard Annotations

### Annotation 1: Campaign ROI Disparity & Strategic Budget Reallocation
- **Location:** Sheet 1 — Marketing Funnel (Positioned adjacent to Campaign ROI & Channel Combo Visuals)
- **Badge:** `ANNOTATION 1: CAMPAIGN ROI DISPARITY & STRATEGIC BUDGET REALLOCATION`
- **Callout Content:**
  - **Performance Gap:** Direct Mail (-92.9% ROI) and Digital Retarget fail to recoup marketing cost.
  - **Top Driver:** Partner Referral (+142% net) and Organic Search (+118%) deliver highest profitability.
  - **Action for Sarah Chen:** Reallocate 20% budget ($70M allocated) from Direct Mail to Partner Referral.
  - **Projected Revenue Impact:** Estimated +$4.2M in attributed pipeline revenue within 2 quarters.

### Annotation 2: Conversion Velocity & Lead-to-Deal Progression
- **Location:** Sheet 1 — Marketing Funnel (Positioned directly over Lead Funnel Progression Visual)
- **Badge:** `ANNOTATION 2: CONVERSION VELOCITY & LEAD-TO-DEAL PROGRESSION`
- **Callout Content:**
  - **Overall Response:** 27.2% overall lead response rate across 2,240 marketing contacts.
  - **Channel Velocity:** Partner Referral leads all channels with 28.5% lead conversion rate.
  - **Bottleneck Flag:** Paid Social exhibits 68% drop-off between Lead and Qualified Opportunity.
  - **Action for Sales/Marketing:** Implement immediate 24h SDR qualification SLA for referral leads.

### Annotation 3: Primary Loss Drivers & Competitive Threat Analysis
- **Location:** Sheet 2 — Sales Pipeline (Positioned adjacent to Deal Value by Stage Visual)
- **Badge:** `ANNOTATION 3: PRIMARY LOSS DRIVERS & COMPETITIVE THREAT ANALYSIS`
- **Callout Content:**
  - **Lost Opportunity Cost:** 184 lost deals represent $37.15M in lost pipeline value (36.9% loss rate).
  - **Two-Thirds Concentration:** Competitor Displacement (38%) and Budget (29%) cause 67% of losses.
  - **Product Vulnerability:** NovaPulse deals suffer 78% of competitive displacement losses.
  - **Action for Sales Enablement:** Arm reps with battlecards countering competitor discounts & pricing.

### Annotation 4: Regional Revenue Concentration & Sales Cycle Velocity
- **Location:** Sheet 2 — Sales Pipeline (Positioned adjacent to Regional Sales Contribution Visual)
- **Badge:** `ANNOTATION 4: REGIONAL REVENUE CONCENTRATION & SALES CYCLE VELOCITY`
- **Callout Content:**
  - **West Region Dominance:** West drives $42.67M (42.3%), followed by Central ($38.71M) and East ($19.53M).
  - **Cycle Length:** Average days-to-close is 62.18 days; won deals take 72.27 days vs 44.45 days for lost.
  - **Enterprise Lengthening:** Enterprise deals require 68.4 days to close due to legal/procurement cycles.
  - **Action for RevOps:** Streamline deal desk approvals for East region to accelerate cycle time.

### Annotation 5: High-Value At-Risk Accounts & Product Downtime Hotspots
- **Location:** Sheet 3 — Customer Health (Positioned adjacent to Product Area Priority Stacked Visual)
- **Badge:** `ANNOTATION 5: HIGH-VALUE AT-RISK ACCOUNTS & PRODUCT DOWNTIME HOTSPOTS`
- **Callout Content:**
  - **Churn Exposure:** Top 10 at-risk accounts (ACCT-083, ACCT-024) filed 55+ tickets each with negative sentiment.
  - **Contract Value at Risk:** These 10 accounts represent over $185,000 in ARR entering critical renewal cycles.
  - **Severe Friction Hotspots:** Analytics Dashboard and Billing cause 44% of tickets and 61% of downtime (28,825 mins).
  - **Action for CS & Engineering:** Deploy immediate SWAT technical reviews and prioritize Analytics stability.
