# Amazon Q in QuickSight — Before/After Topic Comparative Audit

## 1. Overview
This audit documents the testing of **Amazon Q in QuickSight** across two distinct phases:
1. **Baseline Phase (Pre-Topic):** Testing default Quick Chat capabilities directly over raw knowledge bases before creating a custom semantic Topic.
2. **Post-Topic Phase:** Testing the same queries after configuring the **NovaTech Revenue Intelligence Topic**, defining field synonyms, setting semantic roles, and binding custom calculated measures.

*Evidence Files:*
- `01_Baseline_Quick_Chat_Interaction.jpg`: Initial questions and baseline assistant response.
- `02_Amazon_Q_Topic_Configuration.png`: QuickSight Topic configuration showing linked dataset, field synonyms, and calculations.
- `03_Post_Topic_Quick_Chat_Responses.png`: Post-Topic response cards showing improved formatting and exact metric resolution.

---

## 2. Side-by-Side Question Comparison

### Question 1: Sales Opportunity Outcomes
> **Prompt:** *"How many deals were Won vs Lost?"*

| Metric / Dimension | Baseline (Pre-Topic) | Post-Topic Configuration | Improvement Rationale |
|---|---|---|---|
| **Understood Terminology** | Raw text match on deals table | Semantic mapping: `deals` → `opportunity_id`, `outcome` → `deal_stage` | Ambiguity between "deals" and "opportunities" eliminated. |
| **Response Format** | Plain unstructured text bullet: "Won: 315 \| Lost: 184" | Rich visual KPI card + formatted breakdown chart | Visual display showing 315 Won ($63.75M) vs 184 Lost ($37.15M). |
| **Win Rate Computation** | Not computed automatically | Calculated automatically: **63.1% Win Rate** | Q automatically applied percentage formula `(Won / Total)`. |
| **Dashboard Cross-Check** | Match (315 / 184) | **Exact Match (315 Won / 184 Lost / 63.1%)** | Verified against Sheet 2 KPI card. |

---

### Question 2: Marketing Engagement Velocity
> **Prompt:** *"What is the campaign response rate?"*

| Metric / Dimension | Baseline (Pre-Topic) | Post-Topic Configuration | Improvement Rationale |
|---|---|---|---|
| **Understood Terminology** | Generic average of binary column `campaign_response` | Grounded measure: `campaign_response` = 1 divided by total leads | Defined synonym `response rate` = `engagement rate` / `conversion`. |
| **Response Output** | Raw unrounded decimal: "27.19%" | Formatted percentage: **27.2%** (609 of 2,240 leads) | Grounded in total marketing universe. |
| **Channel Context** | None provided | Automatically appended breakdown showing **Partner Referral (28.5%)** as top performer | Q recognized channel dimension linked to campaign performance. |
| **Dashboard Cross-Check** | Match (27.2%) | **Exact Match (27.2% overall, 28.5% Partner Referral)** | Verified against Sheet 1 Response Rate visual. |

---

### Question 3: Customer Support Ticket Severity
> **Prompt:** *"How many tickets are critical priority?"*

| Metric / Dimension | Baseline (Pre-Topic) | Post-Topic Configuration | Improvement Rationale |
|---|---|---|---|
| **Understood Terminology** | Literal string filter on `priority` | Grounded semantic dimension: `priority` = `severity level` / `urgency` | Linked to support friction domain in unified dataset. |
| **Response Output** | Plain text: "50" | Grounded KPI card: **50 Critical Tickets (1.67% of total 3,000)** | Q placed the count in perspective against total ticket volume. |
| **Cross-System Context** | Isolated to support file | Cross-referenced to **Analytics Dashboard & Billing** downtime hotspots and at-risk accounts | Q utilized the unified dataset's left-join relations. |
| **Dashboard Cross-Check** | Match (50) | **Exact Match (50 critical tickets, 1.67%)** | Verified against Sheet 3 KPI and Priority Stacked Bar. |

---

## 3. Reflection: Q vs. Dashboard in Practice

1. **Where did Q agree with the dashboard?**
   Amazon Q agreed 100% on discrete, single-table aggregations (total deals: 499, total marketing leads: 2,240, total tickets: 3,000, critical tickets: 50, overall win rate: 63.1%).
2. **Where did Q disagree or require topic intervention?**
   Q initially struggled with multi-table financial aggregates (such as raw unjoined campaign spend of $12.36M versus joined multi-touch pipeline attribution of $353.51M). Explicitly configuring `campaign_roi` and field synonyms inside the Topic resolved this divergence.
3. **When to use Q vs. the Dashboard?**
   - **Use Amazon Q for:** Fast, natural language ad-hoc questions during meetings (e.g. *"What is the average closing time for West region deals?"*).
   - **Use the Dashboard for:** Multi-dimensional cohort filtering, spotting monthly trends, and weekly cross-functional leadership alignment.
