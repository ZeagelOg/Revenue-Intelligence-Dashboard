# NovaTech Solutions — Data Transformation & Modeling Documentation

## 1. SPICE Datasets Ingestion & Verification
All three raw CSV source files were imported into **Amazon QuickSight** and stored using **SPICE (Super-fast, Parallel, In-memory Calculation Engine)** to provide low-latency queries and support natural language processing via Amazon Q:

| Dataset Name | Source File | SPICE Row Count | SPICE Column Count | Scope / Date Range | Join Role |
|---|---|---|---|---|---|
| **NovaTech CRM Deals** | `novatech_crm_deals.csv` | **499** | **20** | 2023-06-17 to 2025-01-25 | Master Anchor Table |
| **NovaTech Marketing Campaigns** | `novatech_marketing_campaigns.csv` | **2,240** | **20** | 2023-01-01 to 2025-01-31 | Left-Joined Table (Channel attribution) |
| **NovaTech Support Tickets** | `novatech_support_tickets.csv` | **3,000** | **20** | 2023-06-01 to 2025-02-28 | Left-Joined Table (Support friction) |
| **NovaTech Unified Dataset** | *Unified Join* | **63,420** | **38** | Multi-touch customer journey | Primary BI & Topic Dataset |

*Evidence Screenshot:* `01_SPICE_Datasets_Overview_Rows_Columns.png` and `02_SPICE_Datasets_Manage_Data.jpg`.

---

## 2. Data Type Corrections Applied
During initial ingestion of `novatech_support_tickets.csv`, several date and numerical metrics were ingested as generic strings. QuickSight data preparation transformations were applied (`Change data type 1` step):

1. `ticket_created_date`: **String → Date** (`yyyy-MM-dd`)
2. `ticket_resolved_date`: **String → Date** (`yyyy-MM-dd HH:mm:ss`)
3. `users_affected`: **String → Integer**
4. `error_rate_pct`: **String → Decimal**
5. `downtime_minutes`: **String → Integer**
6. `tickets_last_30_days`: **String → Integer**
7. `payment_impact`: **String → Integer**
8. `security_incident`: **String → Integer**
9. `data_loss`: **String → Integer**

*Evidence Screenshot:* `03_Data_Type_Corrections_Support_Tickets.jpg`.

---

## 3. Calculated Fields Implemented
Custom business metrics were authored using QuickSight calculation formulas:

### A. Sales Closing Duration (`days_to_close`)
- **Dataset:** `novatech_crm_deals.csv`
- **Formula:** `dateDiff({deal_created_date}, {deal_closed_date}, 'DD')`
- **Purpose:** Measures the velocity of the sales cycle from initial opportunity logging to final deal resolution.
- *Evidence Screenshot:* `04_Calculated_Field_CRM_Days_To_Close.jpg`

### B. Marketing Campaign Return on Investment (`campaign_roi`)
- **Dataset:** `novatech_marketing_campaigns.csv`
- **Formula:** `({revenue_attributed} - {campaign_spend}) / {campaign_spend}`
- **Purpose:** Identifies channels delivering net-positive revenue return versus underperforming channels operating at a loss.
- *Evidence Screenshot:* `05_Calculated_Field_Marketing_Campaign_ROI.jpg`

---

## 4. Unified Dataset Join Architecture & Configuration
To eliminate data silos across the customer revenue lifecycle, a unified data model was built using `account_id` as the anchor key:

```
[ novatech_crm_deals.csv ]  (Anchor: 499 deals, 85 active accounts)
         │
         │  LEFT JOIN on account_id = account_id
         ▼
[ Join 1: CRM + Marketing Campaigns ] (Attributed leads & spend)
         │
         │  LEFT JOIN on account_id = account_id
         ▼
[ Join 2: NovaTech Unified Dataset ] (3,000 support tickets & downtime)
```

- **Anchor Entity:** `novatech_crm_deals.csv` serves as the primary table.
- **Join Type:** **Left Outer Join** ensures no CRM opportunities are dropped even if an account has zero marketing leads or zero support tickets.
- **Shared Key:** `account_id` (format: `ACCT-XXX`).
- **Orphan IDs Handled:** Marketing and Support contain orphan accounts (`ACCT-101` through `ACCT-115`), representing pre-pipeline website traffic and free tier tickets. The Left Join purposefully anchors to known revenue accounts.
- **SPICE Storage:** The unified dataset comprises **63,420 rows** and **38 columns**, fully cached in SPICE for sub-second dashboard performance.

*Evidence Screenshot:* `06_Unified_Dataset_Join_Diagram_and_Config.jpg`.
